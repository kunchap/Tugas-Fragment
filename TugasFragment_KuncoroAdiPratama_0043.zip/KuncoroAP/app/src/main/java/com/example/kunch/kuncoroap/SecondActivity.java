package com.example.kunch.kuncoroap;

import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.example.kunch.kuncoroap.ui.blankfragment2.BlankFragment2;
import com.example.x550z.ariffauzan.BlankFragment;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
    }

    public void frag1(View view) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager();
        fragmentTransaction.replace(R.id.frame_fragment, new BlankFragment());
        fragmentTransaction.commit();
    }

    public void frag2(View view) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.frame_fragment, new BlankFragment2());
        fragmentTransaction.commit();
    }
}
