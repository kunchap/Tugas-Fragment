package com.example.kunch.kuncoroap.ui.blankfragment2;

import android.arch.lifecycle.ViewModel;

public class BlankFragment2ViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
